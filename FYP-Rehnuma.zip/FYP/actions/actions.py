# This files contains your custom actions which can be used to run custom Python code.

# See this guide on how to implement these action:
# https://rasa.com/docs/rasa/custom-actions

# This is a simple example for a custom action which utters "Hello World!"

from typing import Any, Text, Dict, List
from rasa_sdk import Action, Tracker
from rasa_sdk.executor import CollectingDispatcher
import webbrowser

class ActionCalculateAggregate(Action):

    def name(self) -> Text:
        return "action_calculate_aggregate"

    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:

        fsc = tracker.get_slot("fsc")
        test = tracker.get_slot("test")
        fscc=float(fsc)
        testt=float(test)

        aggregate = (((fscc/1100)*100)/2) + (testt/2)

        dispatcher.utter_message(text="aap ka aggregate ye banta hai: {}".format(aggregate))
        return []

class ActionBusTimings(Action):
    def name(self) -> Text:
        return "action_bus_timings"

    def run(self, dispatcher: CollectingDispatcher,
             tracker: Tracker,
             domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
        city = tracker.get_slot("city")
        time = ""
        if (city == "taxila" or city == "Taxila"):
            time = "05:15 PM"
        else:
            time = "02:00 PM & 05:15 PM"
        dispatcher.utter_message("{} k liye bus ki timings ye hai: {}".format(city, time))
        #dispatcher.utter_message(text="Hello World!")
        return []

class ActionTotalSeats(Action):
    def name(self) -> Text:
        return "action_total_seats"

    def run(self, dispatcher: CollectingDispatcher,
             tracker: Tracker,
             domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:

        degree = tracker.get_slot("degree")
        seats = "250"
        if (degree == "CS" or degree == "cs"):
            seats = "600"
        elif (degree == "EE" or degree == "ee"):
            seats = "300"

        dispatcher.utter_message("{} k liye total {} seats hoti hain".format(degree, seats))
        #dispatcher.utter_message(text="Hello World!")
        return []

class ActionTestPattern(Action):
    def name(self) -> Text:
        return "action_test_pattern"

    def run(self, dispatcher: CollectingDispatcher,
             tracker: Tracker,
             domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:

        degree = tracker.get_slot("degree")
        grad_program = tracker.get_slot("grad_program")

        webbrowser.open_new("https://www.nu.edu.pk/Admissions/TestPattren")

        #dispatcher.utter_message("{}({}) ka sall {} mai closing merit {} tha!".format(grad_program, degree, year, merit))
        return []

class ActionClosingMerit(Action):
    def name(self) -> Text:
        return "action_closing_merit"

    def run(self, dispatcher: CollectingDispatcher,
             tracker: Tracker,
             domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:

        degree = tracker.get_slot("degree")
        year = tracker.get_slot("year")
        grad_program = tracker.get_slot("grad_program")

        merit = "75.5"
        if (year == "2018"):
            merit = "72.5"
        elif (year == "2019"):
            merit = "83.9"

        dispatcher.utter_message("{}({}) ka sall {} mai closing merit {} tha!".format(grad_program, degree, year, merit))
        return []

class ActionHelloWorld(Action):

    def name(self) -> Text:
        return "action_hello_world"

    def run(self, dispatcher: CollectingDispatcher,
             tracker: Tracker,
             domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:

        dispatcher.utter_message(text="Hello World!")
        return []
